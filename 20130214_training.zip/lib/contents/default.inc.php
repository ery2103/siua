<?php
/**
 * Copyright (C) 2007,2008  Arie Nugraha (dicarve@yahoo.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

// be sure that this file not accessed directly
if (!defined('INDEX_AUTH')) {
    die("can not access this file directly");
} elseif (INDEX_AUTH != 1) {
    die("can not access this file directly");
}

/* Showing list of catalogues and also for searching handling */

// include required class class
// require SIMBIO_BASE_DIR.'simbio_UTILS/simbio_tokenizecql.inc.php';
require SIMBIO_BASE_DIR.'simbio_GUI/paging/simbio_paging.inc.php';
require LIB_DIR.'biblio_list_model.inc.php';
// index choice
if ($sysconf['index']['type'] == 'index') {
    require LIB_DIR.'biblio_list_index.inc.php';
} else if ($sysconf['index']['type'] == 'sphinx' && file_exists(LIB_DIR.'sphinx/sphinxapi.php')) {
    require LIB_DIR.'sphinx/sphinxapi.php';
    require LIB_DIR.'biblio_list_sphinx.inc.php';
    $sysconf['opac_result_num'] = (int)$sysconf['opac_result_num'];
} else {
    require LIB_DIR.'biblio_list.inc.php';
}

// create biblio list object
try {
    $biblio_list = new biblio_list($dbs, $sysconf['opac_result_num']);
} catch (Exception $err) {
    die($err->getMessage());
}

if (isset($sysconf['enable_xml_detail']) && !$sysconf['enable_xml_detail']) {
    $biblio_list->xml_detail = false;
}

// if we are in searching mode
if (isset($_GET['search']) && !empty($_GET['search'])) {
    // default vars
    $is_adv = false;
    $keywords = '';
    $criteria = '';
    // simple search
    if (isset($_GET['keywords'])) {
        $keywords = trim(strip_tags(urldecode($_GET['keywords'])));
    }
    if ($keywords && !preg_match('@[a-z0-9_.]+=[^=]+\s+@i', $keywords.' ')) {
        $words = explode(' ', $keywords);
        if (count($words) > 1) {
            if (ISSET($concat_sql) AND $concat_sql == "") {
				$concat_sql = ' AND (';
			} else {
				$concat_sql = '(';
			}
            foreach ($words as $word) {
                $concat_sql .= " (r.perihal LIKE '%$word%' OR r.no_surat LIKE '%$word%' OR desposisi LIKE '%$word%' OR desposisi_dinas LIKE '%$word%' OR desposisi_tugas LIKE '%$word%' OR r.notes LIKE '%$word%' OR r.pengirim_id LIKE '%$word%' OR r.kategori_id LIKE '%$word%') AND";
            }
            // remove the last AND
            $concat_sql = substr_replace($concat_sql, '', -3);
            $concat_sql .= ') ';
            $criteria .= $concat_sql;
        } else {
            $criteria .= ' (r.perihal LIKE \'%'.$keywords.'%\' OR r.desposisi LIKE \'%'.$keywords.'%\' OR r.desposisi_dinas LIKE \'%'.$keywords.'%\' OR r.desposisi_tugas LIKE \'%'.$keywords.'%\' OR r.no_surat LIKE \'%'.$keywords.'%\' OR r.notes LIKE \'%'.$keywords.'%\' OR r.pengirim_id LIKE \'%'.$keywords.'%\' OR r.kategori_id LIKE \'%'.$keywords.'%\')';
        }

        //$criteria = 'r.perihal LIKE \'%'.$keywords.'%\' OR r.pengirim_id LIKE \'%'.$keywords.'%\' OR r.notes LIKE \'%'.$keywords.'%\' OR r.kategori_id LIKE \'%'.$keywords.'%\'';
        $biblio_list->setSQLcriteria($criteria);
    } else {
        $biblio_list->setSQLcriteria($keywords);
    }
    // advanced search
    $is_adv = isset($_GET['search']) || isset($_GET['perihal']) || isset($_GET['pengirim']) || isset($_GET['no_surat'])
        || isset($_GET['notes']) || isset($_GET['penerima'])
        || isset($_GET['ruas']) || isset($_GET['gmd']) || isset($_GET['no_panggil']) || isset($_GET['location']);
    if ($is_adv) {
        $perihal = '';
        if (isset($_GET['perihal'])) {
            $perihal = trim(strip_tags(urldecode($_GET['perihal'])));
        }
        $pengirim = '';
        if (isset($_GET['pengirim'])) {
            $pengirim = trim(strip_tags(urldecode($_GET['pengirim'])));
        }
        $no_surat = '';
        if (isset($_GET['no_surat'])) {
            $no_surat = trim(strip_tags(urldecode($_GET['no_surat'])));
        }
        $notes = '';
        if (isset($_GET['notes'])) {
            $notes = trim(strip_tags(urldecode($_GET['notes'])));
        }
        $penerima = '';
        if (isset($_GET['penerima'])) {
            $penerima = trim(strip_tags(urldecode($_GET['penerima'])));
        }
        $ruas = '';
        if (isset($_GET['ruas'])) {
            $ruas = trim(strip_tags(urldecode($_GET['ruas'])));
        }
        $location = '';
        if (isset($_GET['location'])) {
            $location = trim(strip_tags(urldecode($_GET['location'])));
        }
        $gmd = '';
        if (isset($_GET['gmd'])) {
            $gmd = trim(strip_tags(urldecode($_GET['gmd'])));
        }
        $no_panggil = '';
        if (isset($_GET['no_panggil'])) {
            $no_panggil = trim(strip_tags(urldecode($_GET['no_panggil'])));
        }
        $tahun = '';
        if (isset($_GET['tahun'])) {
            $tahun = trim(strip_tags(urldecode($_GET['tahun'])));
        }
        
        // don't do search if all search field is empty
        if ($perihal || $pengirim || $no_surat || $notes || $penerima || $ruas || $location || $gmd || $no_panggil || $tahun ) {
            $criteria = '';
            if ($perihal) { $criteria .= ' perihal LIKE \'%'.$perihal.'%\''; }
            if ($pengirim) {
				if ( $criteria == "") {
					$criteria .= ' pengirim_id LIKE \'%'.$pengirim.'%\'';
				} else {
					$criteria .= ' AND pengirim_id LIKE \'%'.$pengirim.'%\''; }}
            if ($no_surat) {
				if ( $criteria == "") {
					$criteria .= ' no_surat LIKE \'%'.$no_surat.'%\''; 
				} else {
					$criteria .= ' AND no_surat LIKE \'%'.$no_surat.'%\''; }}
            if ($notes) {
				if ( $criteria == "") {
					$criteria .= ' notes LIKE \'%'.$notes.'%\''; 
				} else {
					$criteria .= ' AND notes LIKE \'%'.$notes.'%\''; }}
            if ($penerima) {
				if ( $criteria == "") {
					$criteria .= ' penerima_id LIKE \'%'.$penerima.'%\'';
				} else {
					$criteria .= ' AND penerima_id LIKE \'%'.$penerima.'%\''; }}
            if ($ruas) {
				if ( $criteria == "") {
					$criteria .= ' kategori_id LIKE \'%'.$ruas.'%\'';
				} else {
					$criteria .= ' AND kategori_id LIKE \'%'.$ruas.'%\''; }}
            if ($location) {
				if ( $criteria == "") {
					$criteria .= ' location_id LIKE \'%'.$location.'%\'';
				} else {
					$criteria .= ' AND location_id LIKE \'%'.$location.'%\''; }}
            if ($gmd) {
				if ( $criteria == "") {
					$criteria .= ' tipe_arsip_id LIKE \'%'.$gmd.'%\'';
				} else {
					$criteria .= ' AND tipe_arsip_id LIKE \'%'.$gmd.'%\''; }}
            if ($no_panggil) {
				if ( $criteria == "") {
					$criteria .= ' no_panggil LIKE \'%'.$no_panggil.'%\'';
				} else {
					$criteria .= ' AND no_panggil LIKE \'%'.$no_panggil.'%\'';}}
            if ($tahun) {
				if ( $criteria == "") {
					$criteria .= ' tgl_surat LIKE \''.$tahun.'%\'';
				} else {
					$criteria .= ' AND tgl_surat LIKE \''.$tahun.'%\'';}}
            $criteria = trim($criteria);
            // die($criteria);
            $biblio_list->setSQLcriteria($criteria);
        }
    }

    // search result info construction
    if ($is_adv) {
        $info .= '<div style="clear: both;">'.__('Found  <strong>{biblio_list->num_rows}</strong> from your keywords').': <strong><cite>'.$keywords.'</cite></strong></div>  '; //mfc
        if ($perihal) { $info .= 'Perihal : <strong><cite>'.$perihal.'</cite></strong>, '; }
        if ($pengirim) { $info .= 'Pengirim : <strong><cite>'.$pengirim.'</cite></strong>, '; }
        if ($no_surat) { $info .= 'No Surat : <strong><cite>'.$no_surat.'</cite></strong>, '; }
        if ($penerima) { $info .= 'Penerima : <strong><cite>'.$penerima.'</cite></strong>, '; }
        if ($gmd) { $info .= 'Tipe arsip : <strong><cite>'.$gmd.'</cite></strong>, '; }
        if ($notes) { $info .= 'Catatan : <strong><cite>'.$notes.'</cite></strong>, '; }
        if ($location) { $info .= 'Lokasi : <strong><cite>'.$location.'</cite></strong>, '; }
        if ($ruas) { $info .= 'Ruas Jalan : <strong><cite>'.$ruas.'</cite></strong>, '; }
        if ($no_panggil) { $info .= 'Nomor Panggil : <strong><cite>'.$no_panggil.'</cite></strong>, '; }
        // strip last comma
        $info = substr_replace($info, '', -2);
    } else {
        $info .= '<div style="clear: both;">'.__('Found  <strong>{biblio_list->num_rows}</strong> from your keywords').': <strong><cite>'.$keywords.'</cite></strong></div>'; //mfc
    }
} else {
    // show promoted titles
    if (isset($sysconf['enable_promote_titles']) && $sysconf['enable_promote_titles']) {
        $biblio_list->only_promoted = true;
    }
}

// check if we are on xml resultset mode
if (isset($_GET['resultXML']) && $sysconf['enable_xml_result']) {
    // get document list but don't output the result
    $biblio_list->getDocumentList(false);
    if ($biblio_list->num_rows > 0) {
        // send http header
        header('Content-Type: text/xml');
        echo '<?xml version="1.0" encoding="UTF-8" ?>'."\n";
        echo $biblio_list->XMLresult();
    }
    exit();
} else {
    // show the list
    echo $biblio_list->getDocumentList();
    echo '<br />'."\n";
    // set result number info
    $info = str_replace('{biblio_list->num_rows}', $biblio_list->num_rows, $info);
}
// count total pages
$total_pages = ceil($biblio_list->num_rows/$sysconf['opac_result_num']);

// page number info
if (isset($_GET['page']) AND $_GET['page'] > 1) {
    $page = intval($_GET['page']);
    $msg = str_replace('{page}', $page, __('You currently on page <strong>{page}</strong> of <strong>{total_pages}</strong> page(s)')); //mfc
    $msg = str_replace('{total_pages}', $total_pages, $msg);
    $info .= '<div style="clear: both;">'.$msg.'</div>';
} else {
    $page = 1;
}
// query time
if (!isset($_SERVER['QUERY_STRING'])) {
	$_SERVER['QUERY_STRING'] = '';
}
$info .= '<div>'.__('Query took').' <b>'.$biblio_list->query_time.'</b> '.__('second(s) to complete').'</div>'; //mfc
if (isset($biblio_list) && isset($sysconf['enable_xml_result']) && $sysconf['enable_xml_result']) {
    $info .= '<div><a href="index.php?resultXML=true&'.$_SERVER['QUERY_STRING'].'" class="xmlResultLink" target="_blank" title="View Result in XML Format" style="clear: both;">XML Result</a></div>';
}
?>
