<?php $sysconf['template']['base'] = 'php'; /* This terrafirma template is designed only for PHP-based templating system */ ?>
