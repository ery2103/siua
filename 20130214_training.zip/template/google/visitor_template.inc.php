<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
<head>
	<title><?php echo $page_title; ?></title>
</head>
<body>
	<?php echo $main_content;?>
</body>
</html>
