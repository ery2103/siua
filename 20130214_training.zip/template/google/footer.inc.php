
	<div id="footer-wrapper" class="footer-wrapper">
		<div id="badges" class="badges">
			<p>
				The Winner in the Category of OSS
				<img src="<?php echo $img;?>/logo-inaicta.png"
					alt="Indonesia ICT Award 2009" border="0" />
			</p>
		</div>
		<div id="copyright" class="copyright">
			<p>
				Powered by <a href="http://slims.web.id/" target="_blank">SLiMS</a> | Design by <a href="http://sutriadi.web.id/" target="_blank">Indra Sutriadi Pipii</a>
			</p>
		</div>
	</div>
