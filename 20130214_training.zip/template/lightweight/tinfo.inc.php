<?php $sysconf['template']['base'] = 'html'; /* html OR php */ ?>
