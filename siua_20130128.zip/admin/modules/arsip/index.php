<?php
/**
 * Copyright (C) 2007,2008,2009,2010  Arie Nugraha (dicarve@yahoo.com)
 * Modified (C) 2012 Wardiyono (wynerst@live.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

/* Archive Meta Data and Management section */

// key to authenticate
define('INDEX_AUTH', '1');

if (!defined('SENAYAN_BASE_DIR')) {
    // main system configuration
    require '../../../sysconfig.inc.php';
    // start the session
    require SENAYAN_BASE_DIR.'admin/default/session.inc.php';
}

require SENAYAN_BASE_DIR.'admin/default/session_check.inc.php';
require SIMBIO_BASE_DIR.'simbio_GUI/table/simbio_table.inc.php';
require SIMBIO_BASE_DIR.'simbio_GUI/form_maker/simbio_form_table_AJAX.inc.php';
require SIMBIO_BASE_DIR.'simbio_GUI/paging/simbio_paging.inc.php';
require SIMBIO_BASE_DIR.'simbio_DB/datagrid/simbio_dbgrid.inc.php';
require SIMBIO_BASE_DIR.'simbio_DB/simbio_dbop.inc.php';
require SIMBIO_BASE_DIR.'simbio_FILE/simbio_file_upload.inc.php';
require MODULES_BASE_DIR.'system/biblio_indexer.inc.php';

// privileges checking
$can_read = utility::havePrivilege('arsip', 'r');
$can_write = utility::havePrivilege('arsip', 'w');

if (!$can_read) {
    die('<div class="errorBox">'.__('You are not authorized to view this section').'</div>');
}

$in_pop_up = false;
// check if we are inside pop-up window
if (isset($_GET['inPopUp'])) {
    $in_pop_up = true;
}

/* RECORD OPERATION */
if (isset($_POST['saveData']) AND $can_read AND $can_write) {
    $perihal = trim(strip_tags($_POST['perihal']));
    // check form validity
    if (empty($perihal)) {
        utility::jsAlert(__('Subject can not be empty'));
        exit();
    } else {
       /* // include custom fields file
        if (file_exists(MODULES_BASE_DIR.'arsip/custom_fields.inc.php')) {
            include MODULES_BASE_DIR.'arsip/custom_fields.inc.php';
        }
*/
        // create biblio_indexer class instance
        $indexer = new biblio_indexer($dbs);

      /*  /**
         * Custom fields
         *
        if (isset($biblio_custom_fields)) {
            if (is_array($biblio_custom_fields) && $biblio_custom_fields) {
                foreach ($biblio_custom_fields as $fid => $cfield) {
                    // custom field data
                    $cf_dbfield = $cfield['dbfield'];
                    if (isset($_POST[$cf_dbfield])) {
                        $cf_val = $dbs->escape_string(strip_tags(trim($_POST[$cf_dbfield]), $sysconf['content']['allowable_tags']));
                        if ($cf_val) {
                            $custom_data[$cf_dbfield] = $cf_val;
                        } else {
                            $custom_data[$cf_dbfield] = 'literal{\'\'}';
                        }
                    }
                }
            }
        }
*/
        $data['perihal'] = $dbs->escape_string($perihal);
        $data['revisi'] = trim($dbs->escape_string(strip_tags($_POST['revisi'])));
        $data['tipe_arsip_id'] = $_POST['tipeArsipID'];
        $data['no_surat'] = trim($dbs->escape_string(strip_tags($_POST['noSurat'])));
        $data['desposisi_dinas'] = trim($dbs->escape_string(strip_tags($_POST['desposisiDinas'])));
        /* // check publisher
        if ($_POST['PengirimID'] != '0') {
            $data['pengirim_id'] = intval($_POST['PengirimID']);
        } else {
            if (!empty($_POST['publ_search_str'])) {
                $new_publisher = trim(strip_tags($_POST['publ_search_str']));
                $new_id = utility::getID($dbs, 'mst_publisher', 'Pengirim_id', 'publisher_name', $new_publisher);
                if ($new_id) {
                    $data['pengirim_id'] = $new_id;
                } else {
                    $data['pengirim_id'] = 'literal{NULL}';
                }
            } else {
                $data['pengirim_id'] = 'literal{NULL}';
            }
        } */
        $data['pengirim_id'] = trim($dbs->escape_string(strip_tags($_POST['pengirim'])));
        $data['tgl_surat'] = trim($dbs->escape_string(strip_tags($_POST['tglArsip'])));
        $data['tgl_terima'] = trim($dbs->escape_string(strip_tags($_POST['tglTerima'])));
        $data['berkas'] = trim($dbs->escape_string(strip_tags($_POST['jumlahBerkas'])));
        $data['no_panggil'] = trim($dbs->escape_string(strip_tags($_POST['noPanggil'])));
        $data['language_id'] = trim($dbs->escape_string(strip_tags($_POST['languageID'])));
        // check place
        if ($_POST['desposisi'] != '0') {
            $data['desposisi'] = intval($_POST['desposisi']);
        } else {
            if (!empty($_POST['plc_search_str'])) {
                $new_place = trim(strip_tags($_POST['plc_search_str']));
                $new_id = utility::getID($dbs, 'mst_place', 'desposisi', 'place_name', $new_place);
                if ($new_id) {
                    $data['desposisi'] = $new_id;
                } else {
                    $data['desposisi'] = 'literal{NULL}';
                }
            } else {
                $data['desposisi'] = 'literal{NULL}';
            }
        }
		$data['status_id'] = trim($dbs->escape_string(strip_tags($_POST['statusID'])));
		$data['notes'] = trim($dbs->escape_string(strip_tags($_POST['notes'])));
		$data['kotak_no'] = trim($dbs->escape_string(strip_tags($_POST['kotakNo'])));
		$data['kategori_id'] = trim($dbs->escape_string(strip_tags($_POST['topikID'])));
        $data['klas_id'] = trim($dbs->escape_string(strip_tags($_POST['filingID'])));;
		$data['location_id'] = trim($dbs->escape_string(strip_tags($_POST['locationID'])));
		$data['room_no'] = trim($dbs->escape_string(strip_tags($_POST['roomNo'])));
		$data['rak_no'] = trim($dbs->escape_string(strip_tags($_POST['rakNo'])));
		$data['baris_rak'] = trim($dbs->escape_string(strip_tags($_POST['barisRak'])));
		$data['kolom_rak'] = trim($dbs->escape_string(strip_tags($_POST['kolomRak'])));
        $data['desposisi_tugas'] = trim($dbs->escape_string(strip_tags($_POST['DesposisiTugas'], '<br><p><div><span><i><em><strong><b><code>s')));
        //$data['opac_hide'] = ($_POST['opacHide'] == '0')?'literal{0}':'1';
        //$data['promoted'] = ($_POST['promote'] == '0')?'literal{0}':'1';
        // labels
        /* $arr_label = array();
        foreach ($_POST['labels'] as $label) {
            if (trim($label) != '') {
                $arr_label[] = array($label, isset($_POST['label_urls'][$label])?$_POST['label_urls'][$label]:null );
            }
        }
        //$data['labels'] = $arr_label?serialize($arr_label):'literal{NULL}';
        //$data['frequency_id'] = ($_POST['frequencyID'] == '0')?'literal{0}':(integer)$_POST['frequencyID']; */
        $data['recod_originalitas'] = trim($dbs->escape_string(strip_tags($_POST['RecordOriginCode'])));
        $data['recod_status'] = trim($dbs->escape_string(strip_tags($_POST['RecordStatusCode'])));
        $data['input_date'] = date('Y-m-d H:i:s');
        $data['last_update'] = date('Y-m-d H:i:s');

   /*     // image uploading
        if (!empty($_FILES['image']) AND $_FILES['image']['size']) {
            // create upload object
            $image_upload = new simbio_file_upload();
            $image_upload->setAllowableFormat($sysconf['allowed_images']);
            $image_upload->setMaxSize($sysconf['max_image_upload']*1024);
            $image_upload->setUploadDir(IMAGES_BASE_DIR.'docs');
            // upload the file and change all space characters to underscore
            $img_upload_status = $image_upload->doUpload('image', preg_replace('@\s+@i', '_', $_FILES['image']['name']));
            if ($img_upload_status == UPLOAD_SUCCESS) {
                $data['image'] = $dbs->escape_string($image_upload->new_filename);
                // write log
                utility::writeLogs($dbs, 'staff', $_SESSION['uid'], 'bibliography', $_SESSION['realname'].' upload image file '.$image_upload->new_filename);
                utility::jsAlert(__('Image Uploaded Successfully'));
            } else {
                // write log
                utility::writeLogs($dbs, 'staff', $_SESSION['uid'], 'bibliography', 'ERROR : '.$_SESSION['realname'].' FAILED TO upload image file '.$image_upload->new_filename.', with error ('.$image_upload->error.')');
                utility::jsAlert(__('Image Uploaded Successfully'));
            }
        }
*/
        // create sql op object
        $sql_op = new simbio_dbop($dbs);
        if (isset($_POST['updateRecordID'])) {
            /* UPDATE RECORD MODE */
            // remove input date
            unset($data['input_date']);
            // filter update record ID
            $updateRecordID = (integer)$_POST['updateRecordID'];
            // update data
            $update = $sql_op->update('recod', $data, 'recod_id='.$updateRecordID);
            // send an alert
            if ($update) {
                // update custom data
               /* if (isset($custom_data)) {
                    // check if custom data for this record exists
                    $_sql_check_custom_q = sprintf('SELECT recod_id FROM biblio_custom WHERE recod_id=%d', $updateRecordID);
                    $check_custom_q = $dbs->query($_sql_check_custom_q);
                    if ($check_custom_q->num_rows) {
                        $update2 = @$sql_op->update('biblio_custom', $custom_data, 'recod_id='.$updateRecordID);
                    } else {
                        $custom_data['recod_id'] = $updateRecordID;
                        @$sql_op->insert('biblio_custom', $custom_data);
                    }
                }*/
            	if ($sysconf['bibliography_update_notification']) {
                    utility::jsAlert(__('Archive Data Successfully Updated'));
			    }
			/*	// auto insert catalog to UCS if enabled
                if ($sysconf['ucs']['enable']) {
                    echo '<script type="text/javascript">parent.ucsUpload(\''.MODULES_WEB_ROOT_DIR.'arsip/ucs_upload.php\', \'itemID[]='.$updateRecordID.'\', false);</script>';
                }
				*/
                // write log
                utility::writeLogs($dbs, 'staff', $_SESSION['uid'], 'Archive', $_SESSION['realname'].' update archive data ('.$data['perihal'].') with recod_id ('.$_POST['itemID'].')');
                // close window OR redirect main page
                if ($in_pop_up) {
                    $itemCollID = (integer)$_POST['itemCollID'];
                    echo '<script type="text/javascript">top.$(\'#mainContent\').simbioAJAX(parent.jQuery.ajaxHistory[0].url, {method: \'post\', addData: \''.( $itemCollID?'itemID='.$itemCollID.'&detail=true':'' ).'\'});</script>';
                    echo '<script type="text/javascript">top.closeHTMLpop();</script>';
                } else {
                    echo '<script type="text/javascript">top.$(\'#mainContent\').simbioAJAX(parent.jQuery.ajaxHistory[0].url);</script>';
                }
                // update index
                // delete from index first
                $sql_op->delete('search_biblio', "recod_id=$updateRecordID");
                $indexer->makeIndex($updateRecordID);
            } else { utility::jsAlert(__('Archive Data FAILED to Updated. Please Contact System Administrator')."\n".$sql_op->error); }
            exit();
        } else {
            /* INSERT RECORD MODE */
            // insert the data
            $insert = $sql_op->insert('recod', $data);
            if ($insert) {
                // get auto id of this record
                $last_biblio_id = $sql_op->insert_id;
                // add authors
                if ($_SESSION['biblioAuthor']) {
                    foreach ($_SESSION['biblioAuthor'] as $author) {
                        $sql_op->insert('biblio_author', array('recod_id' => $last_biblio_id, 'author_id' => $author[0], 'level' => $author[1]));
                    }
                }
                // add topics
                if ($_SESSION['biblioTopic']) {
                    foreach ($_SESSION['biblioTopic'] as $topic) {
                        $sql_op->insert('biblio_topic', array('recod_id' => $last_biblio_id, 'topic_id' => $topic[0], 'level' => $topic[1]));
                    }
                }
                // add recipient
                if ($_SESSION['recodPenerima']) {
                    foreach ($_SESSION['recodPenerima'] as $penerima) {
                        $sql_op->insert('recod_penerima', array('recod_id' => $last_biblio_id, 'unitkerja_id' => $penerima[0], 'instruksi' => $penerima[1]));
                    }
                }
                // add instruksi
                if ($_SESSION['recodInstruksi']) {
                    foreach ($_SESSION['recodInstruksi'] as $instruksi) {
                        $sql_op->insert('recod_instruksi', array('recod_id' => $last_biblio_id, 'unitkerja_id' => $instruksi[0], 'instruksi' => $instruksi[1]));
                    }
                }
                // add disposisi
                if ($_SESSION['recodDisposisi']) {
                    foreach ($_SESSION['recodDisposisi'] as $disposisi) {
                        $sql_op->insert('recod_disposisi', array('recod_id' => $last_biblio_id, 'unitkerja_id' => $disposisi[0], 'instruksi' => $disposisi[1]));
                    }
                }
                // add attachment
                if ($_SESSION['biblioAttach']) {
                    foreach ($_SESSION['biblioAttach'] as $attachment) {
                        $sql_op->insert('biblio_attachment', array('recod_id' => $last_biblio_id, 'file_id' => $attachment['file_id'], 'access_type' => $attachment['access_type']));
                    }
                }
              /*  // insert custom data
                if ($custom_data) {
                    $custom_data['recod_id'] = $last_biblio_id;
                    @$sql_op->insert('biblio_custom', $custom_data);
                }
				*/

                utility::jsAlert(__('New Archive Data Successfully Saved'));
                // write log
                utility::writeLogs($dbs, 'staff', $_SESSION['uid'], 'archive', $_SESSION['realname'].' insert archive data ('.$data['perihal'].') with recod_id ('.$last_biblio_id.')');
                // clear related sessions
                $_SESSION['biblioAuthor'] = array();
                $_SESSION['biblioTopic'] = array();
                $_SESSION['biblioAttach'] = array();
                $_SESSION['recodInstruksi'] = array();
                $_SESSION['recodDisposisi'] = array();
                $_SESSION['recodPenerima'] = array();
                // update index
                $indexer->makeIndex($last_biblio_id);
                // auto insert catalog to UCS if enabled
                if ($sysconf['ucs']['enable'] && $sysconf['ucs']['auto_insert']) {
                    echo '<script type="text/javascript">parent.ucsUpload(\''.MODULES_WEB_ROOT_DIR.'arsip/ucs_upload.php\', \'itemID[]='.$last_biblio_id.'\');</script>';
                }
                echo '<script type="text/javascript">parent.$(\'#mainContent\').simbioAJAX(\''.MODULES_WEB_ROOT_DIR.'arsip/index.php\', {method: \'post\', addData: \'itemID='.$last_biblio_id.'&detail=true\'});</script>';
            } else { utility::jsAlert(__('Archive Data FAILED to Save. Please Contact System Administrator')."\n".$sql_op->error); }
            exit();
        }
    }
    exit();
} else if (isset($_POST['itemID']) AND !empty($_POST['itemID']) AND isset($_POST['itemAction'])) {
    if (!($can_read AND $can_write)) {
        die();
    }
    /* DATA DELETION PROCESS */
    // create sql op object
    $sql_op = new simbio_dbop($dbs);
    $failed_array = array();
    $error_num = 0;
    $still_have_item = array();
    if (!is_array($_POST['itemID'])) {
        // make an array
        $_POST['itemID'] = array((integer)$_POST['itemID']);
    }
    // loop array
    $http_query = '';
    foreach ($_POST['itemID'] as $itemID) {
        $itemID = (integer)$itemID;
        // check if this biblio data still have an item
        $_sql_biblio_item_q = sprintf('SELECT b.perihal, COUNT(item_id) FROM biblio AS b
            LEFT JOIN item AS i ON b.recod_id=i.recod_id
            WHERE b.recod_id=%d GROUP BY perihal', $itemID);
        $biblio_item_q = $dbs->query($_sql_biblio_item_q);
        $biblio_item_d = $biblio_item_q->fetch_row();
        if ($biblio_item_d[1] < 1) {
            if (!$sql_op->delete('recod', "recod_id=$itemID")) {
                $error_num++;
            } else {
                // write log
                utility::writeLogs($dbs, 'staff', $_SESSION['uid'], 'Archive', $_SESSION['realname'].' DELETE Archive data ('.$biblio_item_d[0].') with recod_id ('.$itemID.')');
                // delete related data
                $sql_op->delete('biblio_topic', "recod_id=$itemID");
                $sql_op->delete('biblio_author', "recod_id=$itemID");
                $sql_op->delete('biblio_attachment', "recod_id=$itemID");
                $sql_op->delete('recod_instruksi', "recod_id=$itemID");
                $sql_op->delete('recod_disposisi', "recod_id=$itemID");
                $sql_op->delete('recod_penerima', "recod_id=$itemID");
                $sql_op->delete('search_biblio', "recod_id=$itemID");
                // add to http query for UCS delete
                $http_query .= "itemID[]=$itemID&";
            }
        } else {
            $still_have_item[] = substr($biblio_item_d[0], 0, 45).'... still have '.$biblio_item_d[1].' copies';
            $error_num++;
        }
    }

    if ($still_have_item) {
        $titles = '';
        foreach ($still_have_item as $perihal) {
            $titles .= $perihal."\n";
        }
        utility::jsAlert(__('Below data can not be deleted:')."\n".$titles);
        echo '<script type="text/javascript">parent.$(\'#mainContent\').simbioAJAX(\''.$_SERVER['PHP_SELF'].'\', {addData: \''.$_POST['lastQueryStr'].'\'});</script>';
        exit();
    }
    // auto delete data on UCS if enabled
    if ($http_query && $sysconf['ucs']['enable'] && $sysconf['ucs']['auto_delete']) {
        echo '<script type="text/javascript">parent.ucsUpdate(\''.MODULES_WEB_ROOT_DIR.'arsip/ucs_update.php\', \'nodeOperation=delete&'.$http_query.'\');</script>';
    }
    // error alerting
    if ($error_num == 0) {
        utility::jsAlert(__('All Data Successfully Deleted'));
        echo '<script type="text/javascript">parent.$(\'#mainContent\').simbioAJAX(\''.$_SERVER['PHP_SELF'].'\', {addData: \''.$_POST['lastQueryStr'].'\'});</script>';
    } else {
        utility::jsAlert(__('Some or All Data NOT deleted successfully!\nPlease contact system administrator'));
        echo '<script type="text/javascript">parent.$(\'#mainContent\').simbioAJAX(\''.$_SERVER['PHP_SELF'].'\', {addData: \''.$_POST['lastQueryStr'].'\'});</script>';
    }
    exit();
}
/* RECORD OPERATION END */

if (!$in_pop_up) {
/* search form */
?>
<fieldset class="menuBox">
<div class="menuBoxInner biblioIcon">
    <?php echo strtoupper(__('Archive(s)')); ?> - <a href="<?php echo MODULES_WEB_ROOT_DIR; ?>arsip/index.php?action=detail" class="headerText2"><?php echo __('Add New Archive'); ?></a>
    &nbsp; <a href="<?php echo MODULES_WEB_ROOT_DIR; ?>arsip/index.php" class="headerText2"><?php echo __('Archive List'); ?></a>
    <?php
    // enable UCS?
    if ($sysconf['ucs']['enable']) {
    ?>
    <div class="marginTop"><a href="#" onclick="ucsUpload('<?php echo MODULES_WEB_ROOT_DIR; ?>arsip/ucs_upload.php', serializeChbox('dataList'))" class="notAJAX ucsUpload"><?php echo __('Upload Selected Archive data to Main Archive Collections*'); ?></a></div>
    <?php
    }
    ?>
    <hr />
    <form name="search" action="<?php echo MODULES_WEB_ROOT_DIR; ?>arsip/index.php" id="search" method="get" style="display: inline;"><?php echo __('Search'); ?> :
    <input type="text" name="keywords" id="keywords" size="30" />
    <select name="field"><option value="0"><?php echo __('All Fields'); ?></option><option value="perihal"><?php echo __('Title/Series Title'); ?> </option><option value="subject"><?php echo __('Topics'); ?></option><option value="author"><?php echo __('Authors'); ?></option><option value="isbn"><?php echo __('ISBN/ISSN'); ?></option><option value="publisher"><?php echo __('Publisher'); ?></option></select>
    <input type="submit" id="doSearch" value="<?php echo __('Search'); ?>" class="button" />
    </form>
</div>
</fieldset>
<?php
/* search form end */
}
/* main content */
if (isset($_POST['detail']) OR (isset($_GET['action']) AND $_GET['action'] == 'detail')) {
    if (!($can_read AND $can_write)) {
        die('<div class="errorBox">'.__('You are not authorized to view this section').'</div>');
    }
    /* RECORD FORM */
    // try query
    $itemID = (integer)isset($_POST['itemID'])?$_POST['itemID']:0;
    $_sql_rec_q = sprintf('SELECT b.*, r.road_name FROM recod AS b
        LEFT JOIN mst_road AS r ON b.kategori_id=r.road_id
        WHERE recod_id=%d', $itemID);
    $rec_q = $dbs->query($_sql_rec_q);
    $rec_d = $rec_q->fetch_assoc();

    // create new instance
    $form = new simbio_form_table_AJAX('mainForm', $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'], 'post');
    $form->submit_button_attr = 'name="saveData" value="'.__('Save').'" class="button"';
    // form table attributes
    $form->table_attr = 'align="center" id="dataList" cellpadding="5" cellspacing="0"';
    $form->table_header_attr = 'class="alterCell" style="font-weight: bold;"';
    $form->table_content_attr = 'class="alterCell2"';

    $visibility = 'makeVisible';
    // edit mode flag set
    if ($rec_q->num_rows > 0) {
        $form->edit_mode = true;
        // record ID for delete process
        if (!$in_pop_up) {
            // form record id
            $form->record_id = $itemID;
        } else {
            $form->addHidden('updateRecordID', $itemID);
            $form->addHidden('itemCollID', $_POST['itemCollID']);
            $form->back_button = false;
        }
        // form record perihal
        $form->record_title = $rec_d['perihal'];
        // submit button attribute
        $form->submit_button_attr = 'name="saveData" value="'.__('Update').'" class="button"';
        // element visibility class toogle
        $visibility = 'makeHidden';

        /*// custom field data query
        $_sql_rec_cust_q = sprintf('SELECT * FROM biblio_custom WHERE recod_id=%d', $itemID);
        $rec_cust_q = $dbs->query($_sql_rec_cust_q);
        $rec_cust_d = $rec_cust_q->fetch_assoc(); */
    }

    // include custom fields file
    if (file_exists(MODULES_BASE_DIR.'arsip/custom_fields.inc.php')) {
        include MODULES_BASE_DIR.'arsip/custom_fields.inc.php';
    }

    /* Form Element(s) */
    // recod perihal
    $form->addTextField('textarea', 'perihal', __('Perihal').'*', $rec_d['perihal'], 'rows="1" style="width: 100%; overflow: auto;"');
	// recod ruas jalan
        // get language data related to this record from database
        $road_q = $dbs->query("SELECT road_code, concat_ws(' - ',area_name, road_name) FROM mst_road ORDER BY area_name, road_name");
        $road_options = array();
        $road_options[] = array("", "Pilih Ruas Tol");
        while ($road_d = $road_q->fetch_row()) {
            $road_options[] = array($road_d[0], $road_d[1]);
        }
    $form->addSelectList('topikID', __('Ruas Jalan'), $road_options, $rec_d['kategori_id']);    
/*    // Road option
        // AJAX expression
        $ajax_exp = "ajaxFillSelect('".SENAYAN_WEB_ROOT_DIR."admin/AJAX_lookup_handler.php', 'mst_road', 'road_id:road_code:area_name:road_name', 'road_id', $('#road_search_str').val())";
        // string element
        if ($rec_d['kategori_id']) {
            $plc_options[] = array($rec_d['road_id'], $rec_d['road_name']);
        }
        $plc_options[] = array('0', __('Ruas Jalan'));
        $str_input = simbio_form_element::selectList('kategori_id', $plc_options, '', 'style="width: 50%;"');
        $str_input .= '&nbsp;';
        $str_input .= simbio_form_element::textField('text', 'road_search_str', $rec_d['kategori_id'], 'style="width: 45%;" onkeyup="'.$ajax_exp.'"');
    $form->addAnything(__('Road Name'), $str_input); */
	// recod pengirim
       /* // AJAX expression
        $ajax_exp = "ajaxFillSelect('".SENAYAN_WEB_ROOT_DIR."admin/AJAX_lookup_handler.php', 'mst_publisher', 'pengirim_id:publisher_name', 'pengirimID', $('#publ_search_str').val())";
        if ($rec_d['publisher_name']) {
            $publ_options[] = array($rec_d['pengirim_id'], $rec_d['publisher_name']);
        }
        $publ_options[] = array('0', __('Pengirim'));
        // string element
        $str_input = simbio_form_element::selectList('pengirimID', $publ_options, '', 'style="width: 50%;"');
        $str_input .= '&nbsp;';
        $str_input .= simbio_form_element::textField('text', 'publ_search_str', $rec_d['publisher_name'], 'style="width: 45%;" onkeyup="'.$ajax_exp.'"');
    $form->addAnything(__('Pengirim'), $str_input); */
	$form->addTextField('text', 'pengirim', __('Pengirim'), $rec_d['pengirim_id'], 'style="width: 40%;"');
	// recod tanggal arsip
    $form->addDateField('tglArsip', __('Tanggal Surat'), $rec_d['tgl_surat']);
//    $form->addTextField('text', 'tglArsip', __('Tanggal Surat'), $rec_d['tgl_surat'], 'style="width: 40%;"');
	// recod No Surat/Dokumen
    $form->addTextField('text', 'noSurat', __('No Surat/Dokumen'), $rec_d['no_surat'], 'style="width: 40%;"');
//  Penerima surat
	$form->addTextField('text', 'penerima', __('Penerima'), $rec_d['penerima_id'], 'style="width: 40%;"');
        $str_input = '<div class="'.$visibility.'"><a class="notAJAX"  href="javascript: openHTMLpop(\''.MODULES_WEB_ROOT_DIR.'arsip/pop_penerima.php?biblioID='.$rec_d['recod_id'].'\', 500, 200, \''.__('         ').'\')">'.__('Tambahkan Penerima').'</a></div>';
        $str_input .= '<iframe name="penerimaIframe" id="penerimaIframe" class="borderAll" style="width: 100%; height: 70px;" src="'.MODULES_WEB_ROOT_DIR.'arsip/iframe_penerima.php?biblioID='.$rec_d['recod_id'].'&block=1"></iframe>';
    $form->addAnything(__('&nbsp;'), $str_input);
	// recod revisi
    $form->addTextField('text', 'revisi', __('Revisi'), $rec_d['revisi'], 'style="width: 40%;"');
    // biblio item add
    /* if (!$in_pop_up AND $form->edit_mode) {
        $str_input = '<div class="makeHidden"><a class="notAJAX" href="javascript: openHTMLpop(\''.MODULES_WEB_ROOT_DIR.'arsip/pop_item.php?inPopUp=true&action=detail&biblioID='.$rec_d['recod_id'].'\', 650, 400, \''.__('Items/Copies').'\')">'.__('Add New Items').'</a></div>';
        $str_input .= '<iframe name="itemIframe" id="itemIframe" class="borderAll" style="width: 100%; height: 70px;" src="'.MODULES_WEB_ROOT_DIR.'arsip/iframe_item_list.php?biblioID='.$rec_d['recod_id'].'&block=1"></iframe>'."\n";
        $form->addAnything('Item(s) Data', $str_input);
    } */
    /* // biblio authors
        $str_input = '<div class="'.$visibility.'"><a class="notAJAX" href="javascript: openHTMLpop(\''.MODULES_WEB_ROOT_DIR.'arsip/pop_author.php?biblioID='.$rec_d['recod_id'].'\', 500, 200, \''.__('Authors/Roles').'\')">'.__('Add Author(s)').'</a></div>';
        $str_input .= '<iframe name="authorIframe" id="authorIframe" class="borderAll" style="width: 100%; height: 70px;" src="'.MODULES_WEB_ROOT_DIR.'arsip/iframe_author.php?biblioID='.$rec_d['recod_id'].'&block=1"></iframe>';
    $form->addAnything(__('Author(s)'), $str_input); */
    // recod jenis arsip
        // get gmd data related to this record from database
        $gmd_q = $dbs->query('SELECT gmd_id, gmd_name FROM mst_gmd');
        $gmd_options = array();
        while ($gmd_d = $gmd_q->fetch_row()) {
            $gmd_options[] = array($gmd_d[0], $gmd_d[1]);
        }
    $form->addSelectList('tipeArsipID', __('Jenis Arsip'), $gmd_options, $rec_d['tipe_arsip_id']);
    // recod asal desposisi
    /*    // AJAX expression
        $ajax_exp = "ajaxFillSelect('".SENAYAN_WEB_ROOT_DIR."admin/AJAX_lookup_handler.php', 'mst_place', 'desposis:place_name', 'desposisi', $('#plc_search_str').val())";
        // string element
        if ($rec_d['place_name']) {
            $plc_options[] = array($rec_d['desposisi'], $rec_d['place_name']);
        }
        $plc_options[] = array('0', __('Asal Desposisi'));
        $str_input = simbio_form_element::selectList('desposisi', $plc_options, '', 'style="width: 50%;"');
        $str_input .= '&nbsp;';
        $str_input .= simbio_form_element::textField('text', 'plc_search_str', $rec_d['place_name'], 'style="width: 45%;" onkeyup="'.$ajax_exp.'"'); 
    $form->addAnything(__('Asal Desposisi'), $str_input); */	

        $lang_q = $dbs->query("SELECT unitkerja_id, unitkerja_nama FROM mst_unitkerja");
        $lang_options = array();
        while ($lang_d = $lang_q->fetch_row()) {
            $lang_options[] = array($lang_d[0], $lang_d[1]);
        }
    $form->addSelectList('desposisi', __('Disposisi asal'), $lang_options, $rec_d['desposisi']);    
	// recod Tugas Dinas
        $str_input = '<div class="'.$visibility.'"><a class="notAJAX"  href="javascript: openHTMLpop(\''.MODULES_WEB_ROOT_DIR.'arsip/pop_instruksi.php?biblioID='.$rec_d['recod_id'].'\', 500, 200, \''.__('         ').'\')">'.__('Tambahkan Instruksi').'</a></div>';
        $str_input .= '<iframe name="instruksiIframe" id="instruksiIframe" class="borderAll" style="width: 100%; height: 70px;" src="'.MODULES_WEB_ROOT_DIR.'arsip/iframe_instruksi.php?biblioID='.$rec_d['recod_id'].'&block=1"></iframe>';
    $form->addAnything(__('&nbsp;'), $str_input);
    // recod Desposisi Dinas
    $form->addTextField('text', 'desposisiDinas', __('Desposisi Dinas'), $rec_d['desposisi_dinas'], 'style="width: 40%;"');
	// recod Tugas Dinas
        $str_input = '<div class="'.$visibility.'"><a class="notAJAX"  href="javascript: openHTMLpop(\''.MODULES_WEB_ROOT_DIR.'arsip/pop_disposisi.php?biblioID='.$rec_d['recod_id'].'\', 500, 200, \''.__('         ').'\')">'.__('Tambahkan Disposisi').'</a></div>';
        $str_input .= '<iframe name="disposisiIframe" id="disposisiIframe" class="borderAll" style="width: 100%; height: 70px;" src="'.MODULES_WEB_ROOT_DIR.'arsip/iframe_disposisi.php?biblioID='.$rec_d['recod_id'].'&block=1"></iframe>';
    $form->addAnything(__('&nbsp;'), $str_input);
    $form->addTextField('textarea', 'DesposisiTugas', __('Tugas Dinas'), $rec_d['desposisi_tugas'], 'style="width: 100%;" rows="2"');    
	// recod tanggal terima
    $form->addDateField('tglTerima', __('Tanggal Terima'), $rec_d['tgl_terima']);
//    $form->addTextField('text', 'tglTerima', __('Tanggal Terima'), $rec_d['tgl_terima'], 'style="width: 40%;"');
    //$form->addTextField('textarea', 'topikID', __('Ruas Jalan'), $rec_d['Topik_id'], 'style="width: 100%;" rows="1"');    
	// filing / klasifikasi
        // get language data related to this record from database
        $lang_q = $dbs->query("SELECT klas_id, klas_nama FROM mst_klasifikasi");
        $lang_options = array();
        while ($lang_d = $lang_q->fetch_row()) {
            $lang_options[] = array($lang_d[0], $lang_d[1]);
        }
    $form->addSelectList('filingID', __('Filing Arsip'), $lang_options, $rec_d['klas_id']);
/*    // biblio topic
        $str_input = '<div class="'.$visibility.'"><a class="notAJAX"  href="javascript: openHTMLpop(\''.MODULES_WEB_ROOT_DIR.'arsip/pop_topic.php?biblioID='.$rec_d['recod_id'].'\', 500, 200, \''.__('         ').'\')">'.__('Tambahkan Masalah').'</a></div>';
        $str_input .= '<iframe name="topicIframe" id="topicIframe" class="borderAll" style="width: 100%; height: 70px;" src="'.MODULES_WEB_ROOT_DIR.'arsip/iframe_topic.php?biblioID='.$rec_d['recod_id'].'&block=1"></iframe>';
    $form->addAnything(__('Masalah'), $str_input); */
	// recod jumlah berkas
    $form->addTextField('text', 'jumlahBerkas', __('Jumlah Berkas'), $rec_d['berkas'], 'style="width: 40%;"');
    // recod language
        // get language data related to this record from database
        $lang_q = $dbs->query("SELECT language_id, language_name FROM mst_language");
        $lang_options = array();
        while ($lang_d = $lang_q->fetch_row()) {
            $lang_options[] = array($lang_d[0], $lang_d[1]);
        }
    $form->addSelectList('languageID', __('Language'), $lang_options, $rec_d['language_id']);
    // record origin
        // get record origin data related to this record from database
        $_origin_q = $dbs->query('SELECT record_origin_code, record_origin_name FROM mst_record_origin');
        $_origin_options = array();
        while ($_origin_d = $_origin_q->fetch_row()) {
            $_origin_options[] = array($_origin_d[0], $_origin_d[1]);
        }
    $form->addSelectList('RecordOriginCode', __('Originalitas Arsip'), $_origin_options, $rec_d['recod_originalitas']);
    // record status
        // get record status data related to this record from database
        $_status_q = $dbs->query('SELECT record_status_code, record_status_name FROM mst_record_status');
        $_status_options = array();
        while ($_status_d = $_status_q->fetch_row()) {
            $_status_options[] = array($_status_d[0], $_status_d[1]);
        }
    $form->addSelectList('RecordStatusCode', __('Status Arsip'), $_status_options, $rec_d['recod_status']);
	// recod file attachment
    $str_input = '<div class="'.$visibility.'"><a class="notAJAX" href="javascript: openHTMLpop(\''.MODULES_WEB_ROOT_DIR.'arsip/pop_attach.php?biblioID='.$rec_d['recod_id'].'\', 600, 300, \''.__('File Attachments').'\')">'.__('Add Attachment').'</a></div>';
    $str_input .= '<iframe name="attachIframe" id="attachIframe" class="borderAll" style="width: 100%; height: 70px;" src="'.MODULES_WEB_ROOT_DIR.'arsip/iframe_attach.php?biblioID='.$rec_d['recod_id'].'&block=1"></iframe>';
    $form->addAnything(__('File Attachment'), $str_input);
    /**
     * Custom fields
     */
    if (isset($biblio_custom_fields)) {
        if (is_array($biblio_custom_fields) && $biblio_custom_fields) {
            foreach ($biblio_custom_fields as $fid => $cfield) {

                // custom field properties
                $cf_dbfield = $cfield['dbfield'];
                $cf_label = $cfield['label'];
                $cf_default = $cfield['default'];
                $cf_data = (isset($cfield['data']) && $cfield['data'])?$cfield['data']:array();

                // custom field processing
                if (in_array($cfield['type'], array('text', 'longtext', 'numeric'))) {
                    $cf_max = isset($cfield['max'])?$cfield['max']:'200';
                    $cf_width = isset($cfield['width'])?$cfield['width']:'50';
                    $form->addTextField( ($cfield['type'] == 'longtext')?'textarea':'text', $cf_dbfield, $cf_label, isset($rec_cust_d[$cf_dbfield])?$rec_cust_d[$cf_dbfield]:$cf_default, 'style="width: '.$cf_width.'%;" maxlength="'.$cf_max.'"');
                } else if ($cfield['type'] == 'dropdown') {
                    $form->addSelectList($cf_dbfield, $cf_label, $cf_data, isset($rec_cust_d[$cf_dbfield])?$rec_cust_d[$cf_dbfield]:$cf_default);
                } else if ($cfield['type'] == 'checklist') {
                    $form->addCheckBox($cf_dbfield, $cf_label, $cf_data, isset($rec_cust_d[$cf_dbfield])?$rec_cust_d[$cf_dbfield]:$cf_default);
                } else if ($cfield['type'] == 'choice') {
                    $form->addRadio($cf_dbfield, $cf_label, $cf_data, isset($rec_cust_d[$cf_dbfield])?$rec_cust_d[$cf_dbfield]:$cf_default);
                } else if ($cfield['type'] == 'date') {
                    $form->addDateField($cf_dbfield, $cf_label, isset($rec_cust_d[$cf_dbfield])?$rec_cust_d[$cf_dbfield]:$cf_default);
                }
            }
        }
    }

    // recod Kategori Arsip
        // get language data related to this record from database
        $lang_q = $dbs->query("SELECT language_id, language_name FROM mst_language");
        $lang_options = array();
        while ($lang_d = $lang_q->fetch_row()) {
            $lang_options[] = array($lang_d[0], $lang_d[1]);
        }
    $form->addSelectList('statusID', __('Kategori Arsip'), $lang_options, $rec_d['status_id']);    
    //$form->addTextField('text', 'StatusID', __('Kategori Arsip'), $rec_d['Status_id'], 'style="width: 100%;"');
    // recod catatan arsip
    $form->addTextField('textarea', 'notes', __('Catatan Arsip'), $rec_d['notes'], 'style="width: 100%;"');
	// recod lokasi simpan
        // get frequency data related to this record from database
        $freq_q = $dbs->query('SELECT location_id, location_name FROM mst_location');
        $freq_options = array();
        while ($freq_d = $freq_q->fetch_row()) {
            $freq_options[] = array($freq_d[0], $freq_d[1]);
        }
        $str_input = simbio_form_element::selectList('locationID', $freq_options, $rec_d['location_id']);
        $str_input .= '&nbsp;';
    $form->addAnything(__('Lokasi Simpan'), $str_input);
	// recod No Simpan
    $form->addTextField('text', 'noPanggil', __('No Simpan'), $rec_d['no_panggil'], 'style="width: 40%;"');
    // recod No Kotak
    $form->addTextField('text', 'kotakNo', __('No Kotak'), $rec_d['kotak_no'], 'style="width: 40%;"');	
	// recod No ruang
    $form->addTextField('text', 'roomNo', __('Nomor Ruang'), $rec_d['room_no'], 'style="width: 40%;"');
    // recod Nomor Rak
    $form->addTextField('text', 'rakNo', __('Nomor Rak'), $rec_d['rak_no'], 'style="width: 40%;"');
	// recod Nomor Baris
    $form->addTextField('text', 'barisRak', __('Posisi Baris'), $rec_d['baris_rak'], 'style="width: 40%;"');
	// recod Nomor kolom
    $form->addTextField('text', 'kolomRak', __('Posisi Kolom'), $rec_d['kolom_rak'], 'style="width: 40%;"');
	
	// $form->addCheckBox('labels', 'Label', $label_options, explode(' ', $rec_d['labels']));

    // edit mode messagge
    if ($form->edit_mode) {
        echo '<div class="infoBox" style="overflow: auto;">'
            .'<div style="float: left; width: 80%;">'.__('You are going to edit biblio data').' : <b>'.$rec_d['perihal'].'</b>  <br />'.__('Last Updated').$rec_d['last_update'].'</div>'; //mfc
            /* if ($rec_d['image']) {
                if (file_exists(IMAGES_BASE_DIR.'docs/'.$rec_d['image'])) {
                    $upper_dir = '';
                    if ($in_pop_up) {
                        $upper_dir = '../../';
                    }
                    echo '<div style="float: right;"><img src="'.$upper_dir.'../lib/phpthumb/phpThumb.php?src=../../images/docs/'.urlencode($rec_d['image']).'&w=53" style="border: 1px solid #999999" /></div>';
                }
            } */
        echo '</div>'."\n";
    }
    // print out the form object
    echo $form->printOut();
} else {
    require SIMBIO_BASE_DIR.'simbio_UTILS/simbio_tokenizecql.inc.php';
    require MODULES_BASE_DIR.'arsip/biblio_utils.inc.php';
    require LIB_DIR.'biblio_list_model.inc.php';

    // number of records to show in list
    $biblio_result_num = ($sysconf['biblio_result_num']>100)?100:$sysconf['biblio_result_num'];

    // create datagrid
    $datagrid = new simbio_datagrid();

    // index choice
    if ($sysconf['index']['type'] == 'index' ||  $sysconf['index']['type'] == 'sphinx' ) {
        if ($sysconf['index']['type'] == 'sphinx') {
            require LIB_DIR.'sphinx/sphinxapi.php';
            require LIB_DIR.'biblio_list_sphinx.inc.php';
        } else {
            require LIB_DIR.'biblio_list_index.inc.php';
        }

        // table spec
        // $table_spec = 'search_biblio AS `index` LEFT JOIN item ON `index`.recod_id=item.recod_id';
        $table_spec = 'search_biblio AS `index`';

        if ($can_read AND $can_write) {
            $datagrid->setSQLColumn('index.recod_id', 'index.perihal AS \''.__('Perihal').'\'', 'index.labels',
                'index.author',
                'index.no_surat AS \''.__('No Surat/Dokumen').'\'',
                'index.last_update AS \''.__('Last Update').'\'');
            /* $datagrid->setSQLColumn('index.recod_id', 'index.perihal AS \''.__('Perihal').'\'', 'index.labels',
                'index.author',
                'index.no_surat AS \''.__('No Surat/Dokumen').'\'',
                'IF(COUNT(item.item_id)>0, COUNT(item.item_id), \'<strong style="color: #f00;">'.__('None').'</strong>\') AS \''.__('Copies').'\'',
                'index.last_update AS \''.__('Last Update').'\''); */
            $datagrid->modifyColumnContent(1, 'callback{showTitleAuthors}');
        } else {
            $datagrid->setSQLColumn('index.perihal AS \''.__('Perihal').'\'', 'index.author', 'index.labels',
                'index.no_surat AS \''.__('No Surat/Dokumen').'\'',
                'index.last_update AS \''.__('Last Update').'\'');
            /* $datagrid->setSQLColumn('index.perihal AS \''.__('Perihal').'\'', 'index.author', 'index.labels',
                'index.no_surat AS \''.__('No Surat/Dokumen').'\'',
                'IF(COUNT(item.item_id)>0, COUNT(item.item_id), \'<strong style="color: #f00;">'.__('None').'</strong>\') AS \''.__('Copies').'\'',
                'index.last_update AS \''.__('Last Update').'\''); */
            $datagrid->modifyColumnContent(1, 'callback{showTitleAuthors}');
        }
        $datagrid->invisible_fields = array(1,2);
        $datagrid->setSQLorder('index.last_update DESC');

        // set group by
        $datagrid->sql_group_by = 'index.recod_id';

    } else {
        require LIB_DIR.'biblio_list.inc.php';

        // table spec
        /* $table_spec = 'biblio LEFT JOIN item ON recod.recod_id=item.recod_id'; */
        $table_spec = 'recod ';

        if ($can_read AND $can_write) {
            $datagrid->setSQLColumn('recod.recod_id', 'recod.recod_id AS bid',
                'CONCAT(recod.perihal, \'<br />\', recod.pengirim_id) AS \''.__('Perihal').'\'',
                'recod.no_surat AS \''.__('No Surat/Dokumen').'\'',
                'recod.last_update AS \''.__('Last Update').'\'');
            /* $datagrid->setSQLColumn('recod.recod_id', 'recod.recod_id AS bid',
                'recod.perihal AS \''.__('Perihal').'\'',
                'recod.no_surat AS \''.__('No Surat/Dokumen').'\'',
                'IF(COUNT(item.item_id)>0, COUNT(item.item_id), \'<strong style="color: #f00;">'.__('None').'</strong>\') AS \''.__('Copies').'\'',
                'recod.last_update AS \''.__('Last Update').'\''); */
           // $datagrid->modifyColumnContent(2, 'callback{showTitleAuthors}');
        } else {
            $datagrid->setSQLColumn('recod.recod_id AS bid', 'CONCAT(recod.perihal, \'<br />\', recod.pengirim_id) AS \''.__('').'\'',
                'recod.no_surat AS \''.__('No Surat/Dokumen').'\'',
                'recod.last_update AS \''.__('Last Update').'\'');
            /* $datagrid->setSQLColumn('recod.recod_id AS bid', 'recod.perihal AS \''.__('').'\'',
                'recod.no_surat AS \''.__('No Surat/Dokumen').'\'',
                'IF(COUNT(item.item_id)>0, COUNT(item.item_id), \'<strong style="color: #f00;">'.__('None').'</strong>\') AS \''.__('Copies').'\'',
                'recod.last_update AS \''.__('Last Update').'\''); */
            // modify column value
            //$datagrid->modifyColumnContent(1, 'callback{showTitleAuthors}');
        }
        $datagrid->invisible_fields = array(0);
        $datagrid->setSQLorder('recod.last_update DESC');

        // set group by
        $datagrid->sql_group_by = 'recod.recod_id';
    }

	$stopwords= "@\sAnd\s|\sOr\s|\sNot\s|\sThe\s|\sDan\s|\sAtau\s|\sAn\s|\sA\s@i";

    // is there any search
    if (isset($_GET['keywords']) AND $_GET['keywords']) {
        $keywords = $dbs->escape_string(trim($_GET['keywords']));
		$keywords = preg_replace($stopwords,' ',$keywords);
        $searchable_fields = array('perihal', 'pengirim', 'notes', 'desposisi_tugas');
        if ($_GET['field'] != '0' AND in_array($_GET['field'], $searchable_fields)) {
            $field = $_GET['field'];
            $search_str = $field.'='.$keywords;
        } else {
            $search_str = '';
            foreach ($searchable_fields as $search_field) {
                $search_str .= $search_field.'='.$keywords.' OR ';
            }
            $search_str = substr_replace($search_str, '', -4);
        }
    
        $biblio_list = new biblio_list($dbs, $biblio_result_num);
        $criteria = $biblio_list->setSQLcriteria($search_str);
    }

    if (isset($criteria)) {
        $datagrid->setSQLcriteria('('.$criteria['sql_criteria'].')');
    }

    // set table and table header attributes
    $datagrid->table_attr = 'align="center" id="dataList" cellpadding="5" cellspacing="0"';
    $datagrid->table_header_attr = 'class="dataListHeader" style="font-weight: bold;"';
    // set delete proccess URL
    $datagrid->chbox_form_URL = $_SERVER['PHP_SELF'];
    $datagrid->debug = true;

    // put the result into variables
    $datagrid_result = $datagrid->createDataGrid($dbs, $table_spec, $biblio_result_num, ($can_read AND $can_write));
    if (isset($_GET['keywords']) AND $_GET['keywords']) {
        $msg = str_replace('{result->num_rows}', $datagrid->num_rows, __('Found <strong>{result->num_rows}</strong> from your keywords')); //mfc
        echo '<div class="infoBox">'.$msg.' : "'.$_GET['keywords'].'"<div>'.__('Query took').' <b>'.$datagrid->query_time.'</b> '.__('second(s) to complete').'</div></div>'; //mfc
    }

    echo $datagrid_result;
}
/* main content end */
?>
