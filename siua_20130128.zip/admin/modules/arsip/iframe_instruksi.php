<?php
/**
 * Copyright (C) 2007,2008  Arie Nugraha (dicarve@yahoo.com)
 * Modified (C) 2012 Wardiyono (wynerst@live.com) for Archive Management
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

/* Disposisi List */

// key to authenticate
define('INDEX_AUTH', '1');

// main system configuration
require '../../../sysconfig.inc.php';
// start the session
require SENAYAN_BASE_DIR.'admin/default/session.inc.php';
require SIMBIO_BASE_DIR.'simbio_GUI/table/simbio_table.inc.php';
require SIMBIO_BASE_DIR.'simbio_DB/simbio_dbop.inc.php';

$sysconf['subject_level'][1] = 'Primary';
$sysconf['subject_level'][2] = 'Additional';

// page title
$page_title = 'Instructions List';
// get id from url
$biblioID = 0;
if (isset($_GET['biblioID']) AND !empty($_GET['biblioID'])) {
    $biblioID = intval($_GET['biblioID']);
}

// start the output buffer
ob_start();
?>
<script type="text/javascript">
function confirmProcess(int_biblio_id, int_item_id)
{
    var confirmBox = confirm('Are you sure to remove selected instruction?' + "\n" + 'Once deleted, it can\'t be restored!');
    if (confirmBox) {
        // set hidden element value
        document.hiddenActionForm.bid.value = int_biblio_id;
        document.hiddenActionForm.remove.value = int_item_id;
        // submit form
        document.hiddenActionForm.submit();
    }
}
</script>
<?php
/* main content */
// topic of removal
if (isset($_GET['removesess'])) {
    $idx = $_GET['removesess'];
    unset($_SESSION['recodInstruksi'][$idx]);
    echo '<script type="text/javascript">';
    echo 'alert(\'Instruction removed!\');';
    echo 'location.href = \'iframe_instruksi.php\';';
    echo '</script>';
}

if (isset($_POST['remove'])) {
    $id = (integer)$_POST['remove'];
    $bid = (integer)$_POST['bid'];
    $sql_op = new simbio_dbop($dbs);
    $sql_op->delete('recod_instruksi', 'unitkerja_id='.$id.' AND recod_id='.$bid);
    echo '<script type="text/javascript">';
    echo 'alert(\'Instruction succesfully removed!\');';
    echo 'location.href = \'iframe_instruksi.php?biblioID='.$bid.'\';';
    echo '</script>';
}

// if biblio ID is set
if ($biblioID) {
    $table = new simbio_table();
    $table->table_attr = 'align="center" style="width: 100%;" cellpadding="2" cellspacing="0"';

    // database list
    $biblio_topic_q = $dbs->query("SELECT bt.*, t.unitkerja_nama, t.unitkerja_utama FROM recod_instruksi AS bt
        LEFT JOIN mst_unitkerja AS t ON bt.unitkerja_id=t.unitkerja_id
        WHERE bt.recod_id=$biblioID");

    $row = 1;
    while ($biblio_topic_d = $biblio_topic_q->fetch_assoc()) {
        // alternate the row color
        $row_class = ($row%2 == 0)?'alterCell':'alterCell2';

        // remove link
        $remove_link = '<a href="#" onclick="confirmProcess('.$biblioID.', '.$biblio_topic_d['unitkerja_id'].')"
            style="color: #FF0000; text-decoration: underline;">Delete</a>';
        $topic = $biblio_topic_d['unitkerja_nama'];
//        $topic_type = $sysconf['subject_type'][$biblio_topic_d['topic_type']];
        $topic_type = $biblio_topic_d['instruksi'];

        $table->appendTableRow(array($remove_link, $topic, $topic_type, '&nbsp;'));
        $table->setCellAttr($row, 0, 'valign="top" class="'.$row_class.'" style="font-weight: bold; width: 10%;"');
        $table->setCellAttr($row, 1, 'valign="top" class="'.$row_class.'" style="font-weight: bold; width: 50%;"');
        $table->setCellAttr($row, 2, 'valign="top" class="'.$row_class.'" style="font-weight: bold; width: 49%;"');
        $table->setCellAttr($row, 3, 'valign="top" class="'.$row_class.'" style="width:1%;"');

        $row++;
    }

    echo $table->printTable();
    // hidden form
    echo '<form name="hiddenActionForm" method="post" action="'.$_SERVER['PHP_SELF'].'"><input type="hidden" name="bid" value="0" /><input type="hidden" name="remove" value="0" /></form>';
} else {
    if ($_SESSION['recodInstruksi']) {
        $table = new simbio_table();
        $table->table_attr = 'align="center" style="width: 100%;" cellpadding="2" cellspacing="0"';

        $row = 1;
        $row_class = 'alterCell2';
        foreach ($_SESSION['recodInstruksi'] as $biblio_session) {
            // remove link
            $remove_link = '<a href="iframe_instruksi.php?removesess='.$biblio_session[0].'"
                style="color: #000000; text-decoration: underline;">Remove</a>';

            if ($biblio_session) {
                $topic_q = $dbs->query("SELECT unitkerja_nama, unitkerja_utama FROM mst_unitkerja WHERE unitkerja_id=".$biblio_session[0]);
                $topic_d = $topic_q->fetch_row();
                $topic = $topic_d[0];
                $topic_type = $topic_d[1];
            }

            $table->appendTableRow(array($remove_link, $topic, $topic_type, '&nbsp;'));
            $table->setCellAttr($row, 0, 'valign="top" class="'.$row_class.'" style="font-weight: bold; background-color: #ffc466; width: 10%;"');
            $table->setCellAttr($row, 1, 'valign="top" class="'.$row_class.'" style="background-color: #ffc466; width: 50%;"');
            $table->setCellAttr($row, 2, 'valign="top" class="'.$row_class.'" style="background-color: #ffc466; width: 20%;"');
            $table->setCellAttr($row, 3, 'valign="top" class="'.$row_class.'" style="background-color: #ffc466; width: 20%;"');

            $row++;
        }

        echo $table->printTable();
    }
}
/* main content end */
$content = ob_get_clean();
// include the page template
require SENAYAN_BASE_DIR.'/admin/'.$sysconf['admin_template']['dir'].'/notemplate_page_tpl.php';
?>
