<?php
/**
 * Copyright (C) 2007,2008  Arie Nugraha (dicarve@yahoo.com)
 * Modified (C) 2012 Wardiyono (wynerst@live.com) for Archive Management
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

/* Disposisi Surat dding Pop Windows */

// key to authenticate
define('INDEX_AUTH', '1');

// main system configuration
require '../../../sysconfig.inc.php';
// start the session
require SENAYAN_BASE_DIR.'admin/default/session.inc.php';
require SIMBIO_BASE_DIR.'simbio_GUI/table/simbio_table.inc.php';
require SIMBIO_BASE_DIR.'simbio_GUI/form_maker/simbio_form_table.inc.php';
require SIMBIO_BASE_DIR.'simbio_DB/simbio_dbop.inc.php';

// page title
$page_title = 'Dispostion List';
// check for biblioID in url
$biblioID = 0;
if (isset($_GET['biblioID']) AND $_GET['biblioID']) {
    $biblioID = (integer)$_GET['biblioID'];
}

// utility function to check subject/topic
function checkUnit($str_unitkerja, $str_subject_type = 't')
{
    global $dbs;
    $_q = $dbs->query('SELECT unitkerja_id FROM mst_unitkerja WHERE unitkerja_nama=\''.$str_unitkerja.'\' OR unitkerja_utama=\''.$str_unitkerja.'\'');
    if ($_q->num_rows > 0) {
        $_d = $_q->fetch_row();
        // return the subject/topic ID
        return $_d[0];
    }
    return false;
}

// start the output buffer
ob_start();
/* main content */
// biblio topic save proccess
if (isset($_POST['save']) AND (isset($_POST['topicID']) OR trim($_POST['search_str']))) {
    $subject = trim($dbs->escape_string(strip_tags($_POST['search_str'])));
    // create new sql op object
    $sql_op = new simbio_dbop($dbs);
    // check if biblioID POST var exists
    if (isset($_POST['biblioID']) AND !empty($_POST['biblioID'])) {
        $data['recod_id'] = (integer)$_POST['biblioID'];
        // check if the topic select list is empty or not
        if (!empty($_POST['topicID'])) {
            $data['unitkerja_id'] = $_POST['topicID'];
        } else if ($subject AND empty($_POST['topicID'])) {
            // check subject
            $subject_id = checkUnit($subject, $_POST['type']);
            if ($subject_id !== false) {
                $data['unitkerja_id'] = $subject_id;
            } else {
                // adding new topic
                $topic_data['unitkerja_nama'] = $subject;
                //$topic_data['topic_type'] = $_POST['type'];
                $topic_data['input_date'] = date('Y-m-d');
                $topic_data['last_update'] = date('Y-m-d');
                // insert new topic to topic master table
                $sql_op->insert('mst_unitkerja', $topic_data);
                // put last inserted ID
                $data['unitkerja_id'] = $sql_op->insert_id;
            }
        }
        $data['instruksi'] = $_POST['level'];

        if ($sql_op->insert('recod_disposisi', $data)) {
            echo '<script type="text/javascript">';
            echo 'alert(\'Disposition Intstruction succesfully updated!\');';
            echo 'parent.setIframeContent(\'disposisiIframe\', \''.MODULES_WEB_ROOT_DIR.'arsip/iframe_disposisi.php?biblioID='.$data['unitkerja_id'].'\');';
            echo '</script>';
        } else {
            utility::jsAlert(__('Instruction FAILED to Add. Please Contact System Administrator')."\n".$sql_op->error);
        }
    } else {
        if (!empty($_POST['topicID'])) {
            // add to current session
            $_SESSION['recodDisposisi'][$_POST['topicID']] = array($_POST['topicID'], $_POST['level']);
        } else if ($subject AND empty($_POST['topicID'])) {
            // check subject
            $subject_id = checkUnit($subject);
            if ($subject_id !== false) {
                $last_id = $subject_id;
            } else {
                // adding new topic
                $topic_data['unitkerja_nama'] = $subject;
                //$topic_data['topic_type'] = $_POST['type'];
                $topic_data['input_date'] = date('Y-m-d');
                $topic_data['last_update'] = date('Y-m-d');
                // insert new topic to topic master table
                $sql_op->insert('mst_unitkerja', $topic_data);
                $last_id = $sql_op->insert_id;
            }
            $_SESSION['recodDisposisi'][$last_id] = array($last_id, $_POST['level']);
        }

        echo '<script type="text/javascript">';
        echo 'alert(\''.__('Instruction added!').'\');';
        echo 'parent.setIframeContent(\'disposisiIframe\', \''.MODULES_WEB_ROOT_DIR.'arsip/iframe_disposisi.php\');';
        echo '</script>';
    }
}

?>

<div style="padding: 5px; background: #CCCCCC;">
<form name="mainForm" action="pop_disposisi.php?biblioID=<?php echo $biblioID; ?>" method="post">
<div>
    <strong><?php echo __('Add Disposition'); ?></strong>
    <hr />
    <form name="searchdisposisi" method="post" style="display: inline;">
    <?php
    $ajax_exp = "ajaxFillSelect('../../AJAX_lookup_handler.php', 'mst_unitkerja', 'unitkerja_id:unitkerja_nama:unitkerja_utama', 'topicID', $('#search_str').val())";
    ?>
    <?php echo __('Working Unit'); ?> : <input type="text" name="search_str" id="search_str" style="width: 30%;" onkeyup="<?php echo $ajax_exp; ?>" />
<?php
/*
    <select name="type" style="width: 20%;"><?php
    foreach ($sysconf['subject_type'] as $type_id => $type) {
        echo '<option value="'.$type_id.'">'.$type.'</option>';
    }
    ?></select>
*/
?>    <input type="hidden" name="level" style="width: 48%;">
    <?php
//    echo '<option value="1">Primary</option>';
//    echo '<option value="2">Additional</option>';
    ?>
    </select>
</div>
<div style="margin-top: 5px;">
<select name="topicID" id="topicID" size="5" style="width: 100%;"><option value="0"><?php echo __('Type to search for existing Working Unit or to add a new one'); ?></option></select>
<?php if ($biblioID) { echo '<input type="hidden" name="biblioID" value="'.$biblioID.'" />'; } ?>
<input type="submit" name="save" value="<?php echo __('Insert To Archive'); ?>" style="margin-top: 5px;" />
</div>
</form>
</div>

<?php
/* main content end */
$content = ob_get_clean();
// include the page template
require SENAYAN_BASE_DIR.'/admin/'.$sysconf['admin_template']['dir'].'/notemplate_page_tpl.php';
?>
