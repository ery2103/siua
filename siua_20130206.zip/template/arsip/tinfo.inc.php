<?php $sysconf['template']['base'] = 'php'; /* html OR php */ ?>
