<?php
// biblio/record detail
// output the buffer
ob_start(); /* <- DONT REMOVE THIS COMMAND */
?>
<table class="border margined" style="width: 99%;" cellpadding="5" cellspacing="0">
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('No Surat/Dokumen'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{no_surat}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Ruas Jalan'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{kategori_id}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Perihal'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{perihal}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Tanggal surat'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{tgl_surat}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Tanggal Terima'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{tgl_terima}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Pengirim'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{pengirim_id}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Penerima'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{penerima}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Catatan'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{notes}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Asal Disposisi'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{desposisi}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Disposisi Dinas'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{desposisi_dinas}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Tugas Dinas'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{desposisi_tugas}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Language'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{language_name}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Jumlah Berkas'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{berkas}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Filling'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{klas_nama}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Revisi'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{revisi}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Jenis Arsip'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{gmd_name}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Kategori Arsip'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{status_id}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Lokasi Simpan'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{location_name}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('No Simpan'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{no_panggil}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('No Kotak'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{kotak_no}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Nomor Ruang'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{room_no}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Nomor Rak'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{rak_no}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Nomor Baris'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{baris_rak}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Nomor Kolom'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{kolom_rak}</td>
</tr>
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('File Attachment'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{file_att}</td>
</tr>
<!-- 
<tr>
<td class="tblHead" style="width: 20%;" valign="top"><?php print __('Availability'); ?></td>
<td class="tblContent" style="width: 80%;" valign="top">{availability}</td>
</tr>
-->
<tr>
<td class="tblHead" style="width: 20%;" valign="top">&nbsp;</td>
<td class="tblContent" style="width: 80%;" valign="top"><a href="javascript: history.back();"><?php print __('Back To Previous'); ?></a></td>
</tr>
</table>
<?php
// put the buffer to template var
$detail_template = ob_get_clean();
?>
